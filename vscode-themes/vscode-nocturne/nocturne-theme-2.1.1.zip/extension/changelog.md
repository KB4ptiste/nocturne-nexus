# Changelog

## 2.1.1

- Added README.md
- Added Media files

## 2.1.0

- Updated `editor.foreground` for better contrast.
- Increased selection contrast.
- Added terminal ANSI palette mapped to theme roles.
- Tuned minimap highlight colors.

## 2.0.0

- Introduced Nocturne base palette.
- Added semantic syntax colors for structure, behavior, values, and diagnostics.
- Initial release as VS Code theme.
